</div>
<!-- end container-fluid -->
<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2017 - 2020 &copy; Simple theme by <a href="#">Coderthemes</a>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->
</div>
<!-- end content -->

</div>
</div>

<script src="css/js/pages/morris.init.js"></script>
<script src="css/libs/morris-js/morris.min.js"></script>
<script src="css/libs/raphael/raphael.min.js"></script>
<script src="css/js/pages/dashboard.init.js"></script>
<script src="css/js/vendor.min.js"></script>
<script src="css/libs/raphael/raphael.min.js"></script>
<script src="css/libs/flot-charts/jquery.flot.js"></script>
<script src="css/libs/flot-charts/jquery.flot.time.js"></script>
<script src="css/libs/flot-charts/jquery.flot.tooltip.min.js"></script>
<script src="css/libs/flot-charts/jquery.flot.resize.js"></script>
<script src="css/libs/flot-charts/jquery.flot.pie.js"></script>
<script src="css/libs/flot-charts/jquery.flot.selection.js"></script>
<script src="css/libs/flot-charts/jquery.flot.stack.js"></script>
<script src="css/libs/flot-charts/jquery.flot.orderBars.js"></script>
<script src="css/libs/flot-charts/jquery.flot.crosshair.js"></script>
<script src="css/libs/flot-charts/jquery.flot.axislabels.js"></script>
<script src="css/libs/moment/moment.min.js"></script>
<script src="css/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="css/libs/switchery/switchery.min.js"></script>
<script src="css/libs/select2/select2.min.js"></script>
<script src="css/libs/parsleyjs/parsley.min.js"></script>
<script src="css/libs/bootstrap-filestyle2/bootstrap-filestyle.min.js"></script>
<script src="css/libs/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
<script src="css/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js"></script>
<script src="css/libs/clockpicker/bootstrap-clockpicker.min.js"></script>
<script src="css/libs/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="css/libs/bootstrap-daterangepicker/daterangepicker.js"></script>

<!-- KNOB JS -->
<script src="css/libs/jquery-knob/jquery.knob.min.js"></script>

<script src="css/js/pages/flot.init.js"></script>

<!-- Required datatable js -->
<script src="css/libs/datatables/jquery.dataTables.min.js"></script>
<script src="css/libs/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Buttons examples -->
<script src="css/libs/datatables/dataTables.buttons.min.js"></script>
<script src="css/libs/datatables/buttons.bootstrap4.min.js"></script>
<script src="css/libs/datatables/dataTables.keyTable.min.js"></script>
<script src="css/libs/datatables/dataTables.select.min.js"></script>
<script src="css/libs/jszip/jszip.min.js"></script>
<script src="css/libs/pdfmake/pdfmake.min.js"></script>
<script src="css/libs/pdfmake/vfs_fonts.js"></script>
<script src="css/libs/datatables/buttons.html5.min.js"></script>
<script src="css/libs/datatables/buttons.print.min.js"></script>

<!-- Responsive examples -->
<script src="css/libs/datatables/dataTables.responsive.min.js"></script>
<script src="css/libs/datatables/responsive.bootstrap4.min.js"></script>

<!-- Summernote js -->
<script src="css/libs/summernote/summernote-bs4.min.js"></script>

<!-- Init js-->
<script src="css/js/pages/form-advanced.init.js"></script>

<!-- Datatables init -->
<script src="css/js/pages/datatables.init.js"></script>

<!-- App js -->
<script src="css/js/app.min.js"></script>

</body>

<script>
    switchDarkMode = () => {
        if (document.getElementById("dark-mode-switch").checked) {
            document.getElementById("bootstrap-stylesheet").href = "css/css/bootstrap-dark.min.css";
            document.getElementById("app-stylesheet").href = "css/css/app-dark.min.css";
        } else {
            document.getElementById("bootstrap-stylesheet").href = "css/css/bootstrap.min.css";
            document.getElementById("app-stylesheet").href = "css/css/app.min.css";
        }
    }
    
    showFullProduct = (id) => {
        
    }
</script>

</html>